# Griot Android nativo

Projeto React Native com interface Android nativa, chat com o Gemini via backend, histórico, memórias e conversa por fala usando os serviços nativos do Android. Não é WebView nem atalho para o site.

## Pastas

- `native-app/`: aplicativo Expo/React Native e projeto Android gerado.
- `backend/nova-live-web/`: backend existente com autenticação Bearer para o app móvel; a chave Gemini permanece no servidor.

## Antes de instalar

Publique o backend com HTTPS e configure `GEMINI_API_KEY`, `SESSION_SECRET` e, para persistência do Render entre reinícios, `DATABASE_URL`. Ao abrir o app, informe a URL HTTPS do backend.

Consulte `native-app/README.md` para instalar dependências e gerar APK. A aba Voz usa reconhecimento de fala e síntese do Android; não é o modo Gemini Live simultâneo do site e não promete continuar ouvindo com a tela bloqueada.

## Gerar o APK pelo GitHub, sem Android Studio ou conta Expo

1. Extraia o ZIP e envie o conteúdo para um repositório GitHub seu, mantendo `.github/` e `native-app/` na raiz.
2. No repositório, abra **Actions** e escolha **Build Griot Android APK**.
3. Toque em **Run workflow** e aguarde a execução terminar.
4. Abra a execução concluída e baixe o artefato **griot-apk**. Dentro dele estará `app-debug.apk`, pronto para instalar no Android.

Esse fluxo compila um APK de teste assinado com a chave de depuração temporária do runner. Para instalar uma atualização feita em outra execução, talvez seja necessário remover a versão anterior primeiro. O APK não inclui a chave Gemini; o app precisa acessar o backend HTTPS configurado no aparelho.
