# Griot AI — aplicativo Android nativo

Esta pasta é uma conversão para React Native/Expo. A tela não usa WebView. O app fala com o backend Griot existente por HTTPS; a chave Gemini continua somente no servidor.

## O que já está convertido

- Acesso como visitante, cadastro e login, com sessão protegida no armazenamento seguro do Android.
- Chat ligado ao Gemini pelo backend, com histórico de conversas.
- Memórias sincronizadas entre chats e opção para salvar/excluir memórias.
- Conversa por voz com reconhecimento de fala nativo do Android e leitura da resposta pelo mecanismo de voz instalado no telefone.
- Endereço do backend configurável no próprio app.

## Preparar

1. Publique o backend web existente em um serviço HTTPS, mantendo `GEMINI_API_KEY` e `SESSION_SECRET` configurados no servidor.
2. Instale Node.js e as dependências deste projeto: `npm install`.
3. Abra o app e informe o endereço HTTPS do backend, por exemplo `https://seu-servico.onrender.com`.
4. Faça login ou entre como visitante.

O backend ganhou suporte a `Authorization: Bearer ...` para o cliente nativo. A sessão continua sendo emitida também como cookie para não quebrar o cliente web.

## Gerar APK

O perfil `preview` em `eas.json` também está configurado para APK instalável pelo EAS. A forma mais simples sem configurar EAS é usar o workflow em `.github/workflows/build-apk.yml` na raiz do pacote: envie o projeto ao GitHub, abra **Actions**, rode **Build Griot Android APK** e baixe o artefato `griot-apk`. Como alternativa, o EAS requer uma conta Expo autenticada; configure o projeto com `npx eas-cli@latest init` e execute `npx eas-cli@latest build --platform android --profile preview`. Também é possível compilar localmente com Android SDK/JDK usando `npx expo prebuild` e `cd android && ./gradlew assembleRelease`.

Este ambiente de edição não tem Android SDK, Gradle nem sessão Expo autenticada, então o APK final precisa ser compilado em um desses ambientes. O ZIP contém o projeto nativo completo e o backend atualizado.

## Voz

A aba Voz usa o reconhecimento de fala disponível no Android e o sintetizador de voz do aparelho. Ela envia cada fala reconhecida ao mesmo backend e fala a resposta recebida. Essa implementação é nativa e independente do microfone do Chrome; ela não é uma cópia do protocolo Gemini Live em tempo real do site e não promete continuar ouvindo com a tela bloqueada.

Se o reconhecimento de fala padrão do Android não estiver instalado ou habilitado, instale/ative um serviço de reconhecimento de fala no aparelho. A disponibilidade e as vozes de síntese dependem do Android e dos idiomas instalados.
