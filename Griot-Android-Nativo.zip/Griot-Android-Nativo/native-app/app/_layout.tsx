import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { View } from 'react-native';

export default function RootLayout() {
  return <View style={{ flex: 1, backgroundColor: '#07111f' }}><StatusBar style="light" /><Stack screenOptions={{ headerShown: false }}><Stack.Screen name="index" /></Stack></View>;
}
