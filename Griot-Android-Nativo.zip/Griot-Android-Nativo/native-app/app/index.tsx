import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import * as Speech from 'expo-speech';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { SafeAreaView } from 'react-native-safe-area-context';

type User = { id: string; name: string; email?: string | null; guest?: boolean; preferences?: any };
type Message = { id?: string; role: 'user' | 'assistant'; text: string; at?: string };
type Conversation = { id: string; title: string; mode: string; updatedAt?: string };
type Memory = { id?: string; text: string; at?: string };

const C = { bg: '#07111f', panel: '#0d1b2b', raised: '#13263a', line: '#203a52', text: '#eff7ff', muted: '#9db0c4', cyan: '#55d9ff', blue: '#4387ff', user: '#123557', danger: '#ff7474' };
const TOKEN_KEY = 'griot.session.token';
const URL_KEY = 'griot.backend.url';

function cleanBase(value: string) { return value.trim().replace(/\/+$/, ''); }
function extractMemory(text: string) {
  const m = text.trim().match(/^(?:ei[,! ]*)?(?:griot[,! ]*)?(?:quero que você se lembre(?: de)?|lembre-se(?: de)?|lembra(?: de)?|guarde(?: na memória)?(?: que)?|memorize(?: que)?)\s+(.+)[.!]?$/i);
  return m?.[1]?.trim().replace(/[.!]+$/, '') || '';
}

export default function Home() {
  const [base, setBase] = useState('');
  const [draftBase, setDraftBase] = useState('');
  const [token, setToken] = useState('');
  const [user, setUser] = useState<User | null>(null);
  const [screen, setScreen] = useState('chat');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authName, setAuthName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [input, setInput] = useState('');
  const [memoryInput, setMemoryInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [initializing, setInitializing] = useState(true);
  const [recognizing, setRecognizing] = useState(false);
  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [status, setStatus] = useState('');
  const messagesRef = useRef<Message[]>([]);
  const busyRef = useRef(false);
  const voiceActiveRef = useRef(false);
  const finalHandled = useRef(false);

  useEffect(() => { messagesRef.current = messages; }, [messages]);
  useEffect(() => { busyRef.current = busy; }, [busy]);
  useEffect(() => { voiceActiveRef.current = voiceActive; }, [voiceActive]);

  const request = useCallback(async (path: string, options: { method?: string; body?: any; auth?: boolean } = {}) => {
    if (!base) throw new Error('Configure primeiro o endereço do servidor.');
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (options.auth !== false && token) headers.Authorization = `Bearer ${token}`;
    let response: Response;
    try {
      response = await fetch(`${base}${path}`, { method: options.method || 'GET', headers, body: options.body === undefined ? undefined : JSON.stringify(options.body) });
    } catch { throw new Error('Não consegui acessar o servidor. Confira o endereço e sua conexão.'); }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Erro do servidor (${response.status}).`);
    return data;
  }, [base, token]);

  useEffect(() => {
    (async () => {
      try {
        const savedBase = await SecureStore.getItemAsync(URL_KEY);
        const savedToken = await SecureStore.getItemAsync(TOKEN_KEY);
        if (savedBase) { setBase(savedBase); setDraftBase(savedBase); }
        if (savedToken) setToken(savedToken);
      } finally { setInitializing(false); }
    })();
  }, []);

  useEffect(() => {
    if (!base || !token) return;
    request('/api/me').then(d => { if (d.user) setUser(d.user); else setToken(''); }).catch(() => setStatus('Não consegui validar a sessão. Entre novamente.'));
  }, [base, token, request]);

  const saveBase = async () => {
    const value = cleanBase(draftBase);
    if (!/^https:\/\//i.test(value)) { Alert.alert('Endereço inválido', 'Use o endereço HTTPS completo do backend.'); return; }
    try {
      const response = await fetch(`${value}/api/status`);
      if (!response.ok) throw new Error();
      await SecureStore.setItemAsync(URL_KEY, value);
      setBase(value); setDraftBase(value); setStatus('Servidor conectado.');
    } catch { Alert.alert('Servidor indisponível', 'Confira o endereço HTTPS e confirme que o backend Griot está publicado.'); }
  };

  const authenticate = async (mode: 'guest' | 'login' | 'register') => {
    setBusy(true); setStatus('');
    try {
      const body = mode === 'guest' ? {} : mode === 'login' ? { email: email.trim(), password } : { name: authName.trim(), email: email.trim(), password };
      const d = await request(`/api/auth/${mode}`, { method: 'POST', body, auth: false });
      if (d.sessionToken) { await SecureStore.setItemAsync(TOKEN_KEY, d.sessionToken); setToken(d.sessionToken); }
      setUser(d.user); setScreen('chat'); await loadConversations(d.sessionToken); await loadMemories(d.sessionToken);
    } catch (e: any) { setStatus(e.message); }
    finally { setBusy(false); }
  };

  const loadConversations = async (bearer?: string) => {
    const hdr = bearer || token;
    if (!hdr) return;
    const r = await fetch(`${base}/api/conversations`, { headers: { Authorization: `Bearer ${hdr}` } });
    const d = await r.json(); if (r.ok) setConversations(d.conversations || []);
  };
  const loadMemories = async (bearer?: string) => {
    const hdr = bearer || token; if (!hdr) return;
    const r = await fetch(`${base}/api/memory`, { headers: { Authorization: `Bearer ${hdr}` } });
    const d = await r.json(); if (r.ok) setMemories(d.memories || []);
  };

  const openConversation = async (id: string) => {
    try { const d = await request(`/api/conversations/${id}`); setConversation(d.conversation); setMessages(d.conversation.messages || []); setScreen('chat'); }
    catch (e: any) { setStatus(e.message); }
  };

  const createConversation = async (mode = 'text') => {
    const d = await request('/api/conversations', { method: 'POST', body: { mode, title: 'Nova conversa' } });
    setConversation(d.conversation); setMessages([]); setScreen(mode === 'voice' ? 'voice' : 'chat');
    setConversations(list => [d.conversation, ...list]); return d.conversation;
  };

  const remember = async (text: string) => {
    const clean = text.trim().slice(0, 600); if (clean.length < 3) return;
    const d = await request('/api/memory', { method: 'POST', body: { text: clean } });
    setMemories(old => old.some(m => m.text.toLocaleLowerCase() === clean.toLocaleLowerCase()) ? old : [d.memory, ...old]);
  };

  const sendText = async (raw = input, fromVoice = false) => {
    const text = raw.trim(); if (!text || busyRef.current) return;
    setBusy(true); busyRef.current = true; setStatus('');
    setInput(''); setVoiceTranscript(text);
    const userMessage: Message = { role: 'user', text, at: new Date().toISOString() };
    setMessages(old => [...old, userMessage]);
    try {
      const conv = conversation || await createConversation(fromVoice ? 'voice' : 'text');
      if (!conversation) setConversation(conv);
      const memoryText = extractMemory(text);
      if (memoryText) await remember(memoryText);
      const d = await request('/api/chat', { method: 'POST', body: { conversationId: conv.id, message: text } });
      const answer: Message = { role: 'assistant', text: d.reply, at: new Date().toISOString() };
      setMessages(old => [...old, answer]);
      if (fromVoice && voiceActiveRef.current) Speech.speak(d.reply, { language: 'pt-BR', onDone: () => { if (voiceActiveRef.current) startRecognition(); }, onStopped: () => { if (voiceActiveRef.current) startRecognition(); } });
      await loadConversations(); await loadMemories();
    } catch (e: any) { setStatus(e.message); setMessages(old => old.slice(0, -1)); }
    finally { setBusy(false); busyRef.current = false; }
  };

  const startRecognition = async () => {
    if (!voiceActiveRef.current || busyRef.current) return;
    finalHandled.current = false;
    const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!permission.granted) { setStatus('Permita o uso do microfone nas configurações do Android.'); setVoiceActive(false); return; }
    try { ExpoSpeechRecognitionModule.start({ lang: 'pt-BR', interimResults: true, continuous: false, maxAlternatives: 1 }); }
    catch (e: any) { setStatus(e.message || 'O reconhecimento de fala não iniciou.'); }
  };
  useSpeechRecognitionEvent('start', () => setRecognizing(true));
  useSpeechRecognitionEvent('end', () => { setRecognizing(false); if (voiceActiveRef.current && !busyRef.current) setTimeout(() => startRecognition(), 450); });
  useSpeechRecognitionEvent('result', event => {
    const result = event.results?.[0]?.transcript || '';
    setVoiceTranscript(result);
    if (event.isFinal && result.trim() && !finalHandled.current) { finalHandled.current = true; ExpoSpeechRecognitionModule.stop(); sendText(result, true); }
  });
  useSpeechRecognitionEvent('error', event => { if (event.error !== 'aborted' && event.error !== 'no-speech') setStatus(event.message || 'Falha no reconhecimento de fala.'); });

  const toggleVoice = async () => {
    if (voiceActive) { voiceActiveRef.current = false; setVoiceActive(false); ExpoSpeechRecognitionModule.abort(); Speech.stop(); setRecognizing(false); return; }
    if (!token) { setStatus('Entre na sua conta para iniciar uma conversa por voz.'); return; }
    if (!conversation) await createConversation('voice');
    voiceActiveRef.current = true; setVoiceActive(true); setScreen('voice'); setStatus(''); await startRecognition();
  };

  const deleteMemory = async (item: Memory) => {
    if (item.id) await request(`/api/memory/${item.id}`, { method: 'DELETE' });
    setMemories(old => old.filter(m => m.text !== item.text));
  };
  const logout = async () => {
    voiceActiveRef.current = false; setVoiceActive(false); ExpoSpeechRecognitionModule.abort(); Speech.stop();
    await SecureStore.deleteItemAsync(TOKEN_KEY); setToken(''); setUser(null); setConversation(null); setMessages([]); setScreen('chat');
  };

  if (initializing) return <SafeAreaView style={s.center}><ActivityIndicator color={C.cyan} /></SafeAreaView>;

  const Button = ({ title, onPress, secondary = false, disabled = false }: any) => <Pressable onPress={onPress} disabled={disabled} style={[s.button, secondary && s.buttonSecondary, disabled && { opacity: 0.55 }]}><Text style={[s.buttonText, secondary && { color: C.text }]}>{title}</Text></Pressable>;
  const Header = ({ title, subtitle }: any) => <View style={s.header}><Text style={s.brand}>✦ GRIOT</Text><Text style={s.title}>{title}</Text>{subtitle ? <Text style={s.muted}>{subtitle}</Text> : null}</View>;

  if (!base) return <SafeAreaView style={s.safe}><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.authWrap}><Header title="Conecte seu Griot" subtitle="Informe o endereço HTTPS do servidor da sua IA."/><TextInput style={s.input} autoCapitalize="none" keyboardType="url" placeholder="https://seu-backend.onrender.com" placeholderTextColor={C.muted} value={draftBase} onChangeText={setDraftBase}/><Button title="Conectar servidor" onPress={saveBase}/><Text style={s.note}>A chave Gemini fica protegida no servidor. Não cole sua chave de API aqui.</Text></KeyboardAvoidingView></SafeAreaView>;

  if (!user) return <SafeAreaView style={s.safe}><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.authWrap}><Header title="Sua IA, no Android" subtitle="Entre para acessar as conversas e memórias do Griot."/>{authMode === 'register' && <TextInput style={s.input} placeholder="Seu nome" placeholderTextColor={C.muted} value={authName} onChangeText={setAuthName}/>}<TextInput style={s.input} autoCapitalize="none" keyboardType="email-address" placeholder="E-mail" placeholderTextColor={C.muted} value={email} onChangeText={setEmail}/><TextInput style={s.input} secureTextEntry placeholder="Senha" placeholderTextColor={C.muted} value={password} onChangeText={setPassword}/>{status ? <Text style={s.error}>{status}</Text> : null}<Button title={busy ? 'Aguarde…' : authMode === 'login' ? 'Entrar' : 'Criar conta'} disabled={busy} onPress={() => authenticate(authMode)}/><Button title="Continuar como visitante" secondary disabled={busy} onPress={() => authenticate('guest')}/><Pressable onPress={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}><Text style={s.link}>{authMode === 'login' ? 'Criar uma conta' : 'Já tenho uma conta'}</Text></Pressable><Pressable onPress={logout}><Text style={s.link}>Trocar endereço do servidor</Text></Pressable></KeyboardAvoidingView></SafeAreaView>;

  const nav = [['chat','Chat','✦'],['voice','Voz','◉'],['history','Histórico','▤'],['memory','Memórias','◈'],['settings','Ajustes','⚙']];
  const currentTitle = screen === 'voice' ? 'Conversa por voz' : screen === 'history' ? 'Histórico' : screen === 'memory' ? 'Memórias' : screen === 'settings' ? 'Ajustes' : conversation?.title || 'Nova conversa';

  return <SafeAreaView style={s.safe}>
    <View style={s.top}><View><Text style={s.brand}>✦ GRIOT</Text><Text style={s.topTitle}>{currentTitle}</Text></View><Pressable style={s.avatar} onPress={logout}><Text style={s.avatarText}>{(user.name || 'I').slice(0,1).toUpperCase()}</Text></Pressable></View>
    {screen === 'chat' && <KeyboardAvoidingView style={s.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={8}><ScrollView style={s.flex} contentContainerStyle={s.messages} keyboardShouldPersistTaps="handled">{messages.length === 0 && <View style={s.welcome}><Text style={s.orb}>✦</Text><Text style={s.title}>Como posso ajudar?</Text><Text style={s.muted}>Converse com o Griot. Ele usa suas memórias e o histórico salvo no servidor.</Text></View>}{messages.map((m,i)=><View key={m.id || `${m.at}-${i}`} style={[s.bubble, m.role === 'user' ? s.userBubble : s.aiBubble]}><Text style={s.bubbleLabel}>{m.role === 'user' ? user.name : 'Griot'}</Text><Text style={s.bubbleText}>{m.text}</Text></View>)}{busy && <View style={s.row}><ActivityIndicator color={C.cyan}/><Text style={s.muted}> Griot está pensando…</Text></View>}{status ? <Text style={s.error}>{status}</Text> : null}</ScrollView><View style={s.composer}><TextInput style={s.messageInput} multiline placeholder="Escreva para o Griot…" placeholderTextColor={C.muted} value={input} onChangeText={setInput}/><Pressable style={s.send} onPress={() => sendText()} disabled={busy}><Text style={s.sendText}>↑</Text></Pressable></View></KeyboardAvoidingView>}

    {screen === 'voice' && <View style={[s.flex,s.voicePage]}><View style={s.voiceOrb}><Text style={s.orb}>✦</Text></View><Text style={s.title}>{voiceActive ? (recognizing ? 'Estou ouvindo você' : busy ? 'Griot está respondendo' : 'Conversa por voz ativa') : 'Fale com o Griot'}</Text><Text style={s.muted}>{voiceTranscript || 'Toque no botão para falar em português.'}</Text>{status ? <Text style={s.error}>{status}</Text> : null}<Button title={voiceActive ? 'Encerrar conversa por voz' : 'Iniciar conversa por voz'} secondary={voiceActive} onPress={toggleVoice}/><Text style={s.note}>A fala é reconhecida pelo serviço de voz do Android. A resposta é gerada pelo backend do Griot e falada pelo aparelho.</Text></View>}

    {screen === 'history' && <ScrollView style={s.flex} contentContainerStyle={s.listPage}><Button title="＋ Nova conversa" onPress={() => createConversation()}/>{conversations.map(item => <Pressable key={item.id} style={s.listCard} onPress={() => openConversation(item.id)}><Text style={s.cardTitle}>{item.title || 'Conversa'}</Text><Text style={s.muted}>{item.mode === 'voice' ? 'Conversa por voz' : 'Chat'}{item.updatedAt ? ` · ${new Date(item.updatedAt).toLocaleDateString('pt-BR')}` : ''}</Text></Pressable>)}{conversations.length === 0 && <Text style={s.muted}>Suas conversas salvas vão aparecer aqui.</Text>}</ScrollView>}

    {screen === 'memory' && <KeyboardAvoidingView style={s.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><View style={s.memoryEntry}><TextInput style={[s.input,{flex:1,marginBottom:0}]} placeholder="O que o Griot deve lembrar?" placeholderTextColor={C.muted} value={memoryInput} onChangeText={setMemoryInput}/><Pressable style={s.smallButton} onPress={async()=>{try{await remember(memoryInput);setMemoryInput('');}catch(e:any){setStatus(e.message)}}}><Text style={s.sendText}>＋</Text></Pressable></View><ScrollView style={s.flex} contentContainerStyle={s.listPage}>{status ? <Text style={s.error}>{status}</Text> : null}{memories.map(item=><View key={item.id || item.text} style={s.listCard}><Text style={s.bubbleText}>{item.text}</Text><Pressable onPress={()=>deleteMemory(item)}><Text style={s.delete}>Excluir memória</Text></Pressable></View>)}{memories.length===0&&<Text style={s.muted}>Nenhuma memória salva ainda.</Text>}</ScrollView></KeyboardAvoidingView>}

    {screen === 'settings' && <ScrollView style={s.flex} contentContainerStyle={s.listPage}><Text style={s.section}>SERVIDOR</Text><TextInput style={s.input} autoCapitalize="none" keyboardType="url" value={draftBase} onChangeText={setDraftBase} placeholder="https://seu-backend.onrender.com" placeholderTextColor={C.muted}/><Button title="Salvar e testar conexão" onPress={saveBase}/>{status ? <Text style={s.muted}>{status}</Text> : null}<Text style={s.section}>CONTA</Text><View style={s.listCard}><Text style={s.cardTitle}>{user.name}</Text><Text style={s.muted}>{user.email || 'Visitante'}</Text></View><Button title="Sair da conta" secondary onPress={logout}/><Text style={s.note}>O Griot mantém suas conversas e memórias no servidor conectado. A chave de API nunca é colocada dentro do aplicativo.</Text></ScrollView>}

    <View style={s.nav}>{nav.map(([id,label,icon])=><Pressable key={id} style={s.navItem} onPress={()=>{setStatus('');setScreen(id);if(id==='history')loadConversations();if(id==='memory')loadMemories();}}><Text style={[s.navIcon,screen===id&&{color:C.cyan}]}>{icon}</Text><Text style={[s.navText,screen===id&&{color:C.cyan}]}>{label}</Text></Pressable>)}</View>
  </SafeAreaView>;
}

const s = StyleSheet.create({ safe:{flex:1,backgroundColor:C.bg},flex:{flex:1},center:{flex:1,backgroundColor:C.bg,justifyContent:'center',alignItems:'center'},authWrap:{flex:1,justifyContent:'center',padding:26},header:{marginBottom:28},brand:{color:C.cyan,fontSize:13,fontWeight:'900',letterSpacing:3},title:{color:C.text,fontSize:25,fontWeight:'800',marginTop:8},muted:{color:C.muted,fontSize:14,lineHeight:21,marginTop:5},input:{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:15,paddingHorizontal:15,paddingVertical:14,color:C.text,marginBottom:13,fontSize:15},button:{backgroundColor:C.blue,borderRadius:15,padding:15,alignItems:'center',marginTop:10},buttonSecondary:{backgroundColor:C.raised,borderWidth:1,borderColor:C.line},buttonText:{fontWeight:'800',color:'#fff',fontSize:15},note:{color:C.muted,fontSize:12,lineHeight:18,marginTop:18,textAlign:'center'},link:{color:C.cyan,textAlign:'center',padding:12,fontWeight:'700'},error:{color:C.danger,fontSize:13,marginTop:10},top:{paddingHorizontal:20,paddingTop:8,paddingBottom:12,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderBottomWidth:1,borderColor:C.line},topTitle:{color:C.text,fontSize:17,fontWeight:'700',marginTop:2},avatar:{width:38,height:38,borderRadius:20,backgroundColor:C.raised,alignItems:'center',justifyContent:'center',borderColor:C.line,borderWidth:1},avatarText:{color:C.cyan,fontWeight:'800'},messages:{padding:16,paddingBottom:28,gap:12},welcome:{flex:1,minHeight:360,justifyContent:'center',alignItems:'center',paddingHorizontal:22},orb:{color:C.cyan,fontSize:38},bubble:{padding:14,borderRadius:17,maxWidth:'92%'},userBubble:{backgroundColor:C.user,alignSelf:'flex-end',borderBottomRightRadius:5},aiBubble:{backgroundColor:C.panel,alignSelf:'flex-start',borderBottomLeftRadius:5,borderWidth:1,borderColor:C.line},bubbleLabel:{color:C.cyan,fontWeight:'800',fontSize:11,marginBottom:6},bubbleText:{color:C.text,fontSize:15,lineHeight:22},row:{flexDirection:'row',alignItems:'center',padding:10},composer:{flexDirection:'row',alignItems:'flex-end',gap:8,paddingHorizontal:12,paddingVertical:10,borderTopWidth:1,borderColor:C.line,backgroundColor:C.bg},messageInput:{flex:1,minHeight:46,maxHeight:120,backgroundColor:C.panel,borderRadius:17,borderWidth:1,borderColor:C.line,paddingHorizontal:14,paddingTop:13,paddingBottom:12,color:C.text,fontSize:15},send:{height:46,width:48,borderRadius:16,backgroundColor:C.blue,alignItems:'center',justifyContent:'center'},sendText:{color:'#fff',fontSize:24,fontWeight:'700'},voicePage:{alignItems:'center',justifyContent:'center',padding:28,gap:13},voiceOrb:{height:180,width:180,borderRadius:100,backgroundColor:'#0d2b44',borderWidth:1,borderColor:'#2c9dc4',alignItems:'center',justifyContent:'center',shadowColor:C.cyan,shadowOpacity:.32,shadowRadius:30,elevation:12},listPage:{padding:16,gap:10},listCard:{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:16,padding:15,marginTop:5},cardTitle:{color:C.text,fontSize:15,fontWeight:'700'},nav:{height:66,flexDirection:'row',justifyContent:'space-around',alignItems:'center',borderTopWidth:1,borderColor:C.line,backgroundColor:'#091625'},navItem:{alignItems:'center',justifyContent:'center',minWidth:54},navIcon:{color:C.muted,fontSize:19},navText:{color:C.muted,fontSize:10,marginTop:2},memoryEntry:{flexDirection:'row',padding:12,gap:8,alignItems:'center'},smallButton:{width:48,height:48,borderRadius:15,backgroundColor:C.blue,alignItems:'center',justifyContent:'center'},delete:{color:C.danger,fontSize:12,fontWeight:'700',marginTop:10},section:{color:C.cyan,fontWeight:'900',fontSize:12,letterSpacing:2,marginTop:15,marginBottom:5}});
